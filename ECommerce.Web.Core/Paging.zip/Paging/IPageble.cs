﻿namespace ECommerce.Web.Core.Paging
{
    public interface IPageble
    {
        PagerViewModel PagerViewModel { get; set; }
    }
}